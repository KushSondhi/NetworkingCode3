[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/4h1OdTyd)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12614131&assignment_repo_type=AssignmentRepo)
## CSC435 Programming Assignment 3 (Fall 2023)
**Jarvis College of Computing and Digital Media - DePaul University**

**Student**: TO-DO-write-student-name (TO-DO-write-email-address)

**Solution programming language**: TO-DO-write-solution-programming-language (Java or C++)

### Requirements

If you are implementing your solution in C++ you will need to have GCC 12.x and CMake 3.22.x installed on your system. On Ubuntu 22.04 you can install GCC and set it as default compiler using the following commands:

```
sudo apt install g++-12 gcc-12 cmake
sudo update-alternatives --remove-all gcc
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-11 110
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-12 120
sudo update-alternatives --install /usr/bin/cc cc /usr/bin/gcc 10
sudo update-alternatives --remove-all g++
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-11 110
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-12 120
sudo update-alternatives --install /usr/bin/c++ c++ /usr/bin/g++ 10
```

If you are implementing your solution in Java you will need to have Java 1.7.x and Maven 3.6.x installed on your systems. On Ubuntu 22.04 you can install Java and Maven using the following commands:

```
sudo apt install openjdk-17-jdk maven

```

### Setup

There are 5 datasets (Dataset1-groups, Dataset2-groups, Dataset3-groups, Dataset4-groups, Dataset5-groups) that you can use to test your solution. Before you can test your solution you need to download the datasets. You can download the datasets from the following link:

https://depauledu-my.sharepoint.com/:f:/g/personal/aorhean_depaul_edu/EgmxmSiWjpVMi8r6QHovyYIB-XWjqOmQwuINCd9N_Ppnug?e=GHzmfS

After you finished downloading the "groups" datasets copy them to the dataset directory (create the directory if it does not exist). Here is an example on how you can copy Dataset1 to the remote machine and how to unzip the dataset:

```
remote-computer$ mkdir datasets
local-computer$ scp Dataset1-groups.zip cc@<remote-ip>:<path-to-repo>/datasets/.
remote-computer$ cd <path-to-repo>/datasets
remote-computer$ unzip Dataset1-groups.zip
```

### C++ solution
#### How to build/compile

To build the C++ solution use the following commands:
```
cd app-cpp
mkdir build
cmake -S . -B build
cmake --build build
```

#### How to run application

To run the C++ server in interactive mode (after you build the project) use the following command:
```
./build/server
> <list | quit>
```

To run the C++ client in interactive mode (after you build the project) use the following command:
```
./build/client
> <connect | index | search | quit>
```

### Java solution
#### How to build/compile

To build the Java solution use the following commands:
```
cd app-java
mvn compile
mvn package
```

#### How to run application

To run the Java server in interactive mode (after you build the project) use the following command:
```
java -cp target/app-java-1.0-SNAPSHOT.jar com.csc435.app.Server
> <list | quit>
```

To run the Java client in interactive mode (after you build the project) use the following command:
```
java -cp target/app-java-1.0-SNAPSHOT.jar com.csc435.app.Client
> <connect | index | search | quit>
```

### How to test solution

To test the solution (after you build the project) use the following commands:

On the server side test the list command after clients connect to the server:
```
> list
client 1: 127.0.0.1 5746
client 2: 127.0.0.1 9677
> 
```

On the client side test the connect, index and search commands:
```
> connect 127.0.0.1 12345
Connection successful!
> index ../datasets/Dataset1/group1
Completed Indexing Dataset1 in 10.384 seconds
> index ../datasets/Dataset1/group2
Completed Indexing Dataset1 in 10.098 seconds
> index ../datasets/Dataset1/group3
Completed Indexing Dataset1 in 10.263 seconds
> index ../datasets/Dataset1/group4
Completed Indexing Dataset1 in 10.463 seconds
> index ../datasets/Dataset1/group5
Completed Indexing Dataset1 in 10.234 seconds
> index ../datasets/Dataset1/group6
Completed Indexing Dataset1 in 10.423 seconds
> index ../datasets/Dataset1/group7
Completed Indexing Dataset1 in 10.456 seconds
> index ../datasets/Dataset1/group8
Completed Indexing Dataset1 in 10.203 seconds
> index ../datasets/Dataset1/group9
Completed Indexing Dataset1 in 10.465 seconds
> index ../datasets/Dataset1/group10
Completed Indexing Dataset1 in 10.708 seconds
> index ../datasets/Dataset1/group11
Completed Indexing Dataset1 in 10.098 seconds
> index ../datasets/Dataset1/group12
Completed Indexing Dataset1 in 10.876 seconds
> index ../datasets/Dataset1/group13
Completed Indexing Dataset1 in 10.284 seconds
> index ../datasets/Dataset1/group14
Completed Indexing Dataset1 in 10.148 seconds
> index ../datasets/Dataset1/group15
Completed Indexing Dataset1 in 10.234 seconds
> index ../datasets/Dataset1/group16
Completed Indexing Dataset1 in 10.869 seconds
> search Worms
Search completed in 2.8 seconds. Search results: Dataset1/group12/document424.txt Dataset1/group6/document260.txt Dataset1/group9/document351.txt Dataset1/group8/document316.txt Dataset1/group16/document79.txt Dataset1/group1/document101.txt Dataset1/group11/document38.txt Dataset1/group4/document200.txt Dataset1/group12/document417.txt
> search distortion AND adaptation
Search completed in 3.27 seconds. Search results: Dataset1/group12/document408.txt Dataset1/group12/document408.txt Dataset1/group4/document200.txt Dataset1/group2/document145.txt Dataset1/group9/document351.txt Dataset1/group4/document216.txt Dataset1/group16/document77.txt Dataset1/group1/document107.txt Dataset1/group7/document27.txt Dataset1/group7/document298.txt Dataset1/group11/document38.txt
> search eulogy OR enviable
Search completed in 7.395 seconds. Search results: Dataset1/group16/document87.txt Dataset1/group16/document87.txt Dataset1/group4/document211.txt Dataset1/group3/document158.txt Dataset1/group2/document143.txt Dataset1/group2/document148.txt Dataset1/group2/document144.txt Dataset1/group15/document498.txt Dataset1/group4/document210.txt Dataset1/group1/document105.txt Dataset1/group13/document457.txt Dataset1/group14/document470.txt Dataset1/group9/document354.txt Dataset1/group9/document331.txt Dataset1/group2/document130.txt Dataset1/group4/document202.txt Dataset1/group4/document180.txt Dataset1/group11/document380.txt Dataset1/group8/document314.txt Dataset1/group8/document306.txt Dataset1/group9/document350.txt Dataset1/group6/document25.txt Dataset1/group3/document178.txt Dataset1/group1/document110.txt Dataset1/group4/document200.txt Dataset1/group14/document476.txt Dataset1/group8/document322.txt Dataset1/group7/document299.txt Dataset1/group13/document452.txt Dataset1/group16/document77.txt Dataset1/group10/document379.txt Dataset1/group7/document27.txt Dataset1/group12/document432.txt Dataset1/group5/document24.txt Dataset1/group8/document305.txt Dataset1/group3/document179.txt Dataset1/group9/document353.txt Dataset1/group12/document408.txt Dataset1/group7/document284.txt Dataset1/group3/document170.txt Dataset1/group3/document160.txt Dataset1/group1/document125.txt Dataset1/group7/document288.txt Dataset1/group9/document348.txt Dataset1/group10/document372.txt Dataset1/group11/document406.txt Dataset1/group14/document48.txt Dataset1/group13/document456.txt Dataset1/group5/document22.txt Dataset1/group15/document491.txt Dataset1/group12/document417.txt Dataset1/group12/document428.txt Dataset1/group7/document293.txt Dataset1/group9/document351.txt Dataset1/group16/document82.txt Dataset1/group13/document453.txt Dataset1/group8/document31.txt Dataset1/group7/document291.txt Dataset1/group2/document145.txt Dataset1/group3/document176.txt Dataset1/group15/document51.txt Dataset1/group1/document107.txt Dataset1/group10/document373.txt Dataset1/group7/document295.txt Dataset1/group13/document450.txt Dataset1/group3/document166.txt Dataset1/group6/document263.txt Dataset1/group1/document103.txt Dataset1/group2/document14.txt Dataset1/group13/document446.txt
>
```

You can then compare your solution's results with the ones from the Dataset-tests-groups.zip files.
