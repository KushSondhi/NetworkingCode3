package com.csc435.app;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class Server {

	private static Map<String, Socket> connectedClients = new ConcurrentHashMap<>();
	static List<Socket> allclientConnections = new ArrayList<>();

	public static void main(String[] args) throws IOException {

		int port = 1111;

		try (ServerSocket ss = new ServerSocket(port)) {

			System.out.println("Listeneing on port : " + port);

			while (true) {

				Socket clientSocket = ss.accept();
				System.out.println("Connected from : " + clientSocket);
				allclientConnections.add(clientSocket);

				new Thread(new ClientHandler(clientSocket)).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	static class ClientHandler implements Runnable {

		private Socket clientSocket;
//		private static List<Socket> allclientConnections;
		private String clientId;

		public ClientHandler(Socket clientSocket) {
			this.clientSocket = clientSocket;
			// this.allclientConnections = allclientConnections;
		}

		@Override
		public void run() {

			Scanner sc;
			String messages;
			try (Scanner in = new Scanner(clientSocket.getInputStream());
					PrintStream out = new PrintStream(clientSocket.getOutputStream())) {

				// System.out.println("Something print");
				while (true) {

					if (!in.hasNextLine()) {
//						System.out.println("Loop end");
						break;
					}
					messages = in.nextLine();
					if (messages != null && !messages.isEmpty()) {
						connectedClients.put(clientSocket.getInetAddress().toString(), clientSocket);

						System.out.println("[CLIENT]: " + messages);
						if (messages.equalsIgnoreCase("list")) {
							System.out.println("calling list method");
							printAllClients(out);
						} else {
							continue;
							//out.println("Msg from CLIENT : " + clientSocket + ": ");
						}
					} else {
						System.out.println("Invalid client identifier. Connection closed. ");
						clientSocket.close();
						return;
					}
				}
			} catch (IOException e) {
////			.close();
				e.printStackTrace();
				// clientSocket.close();
//			System.out.println("Connected Stopped..");
//			break;
			}
		}

		public static void printAllClients(PrintStream out) {
			System.out.println("All Clients : ");
			out.println(allclientConnections.toString());
//			for (Socket client : allclientConnections) {
//				out.println(client.getInetAddress().getHostAddress());
//			}
		}
	}
}
