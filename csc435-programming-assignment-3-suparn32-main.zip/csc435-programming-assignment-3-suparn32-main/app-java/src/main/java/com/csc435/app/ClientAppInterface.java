package com.csc435.app;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class ClientAppInterface {

//	private ClientSideEngine engine;
	private Socket socket = new Socket();
	private DataInputStream input = new DataInputStream(System.in);
	private DataOutputStream out = null;
	private String setdatasetvalue = "";
	private String groupValue = "";

	public ClientAppInterface(ClientSideEngine engine) {
//		this.engine = engine;

	}

	public Set<String> IndexMethod(String command) {

		Set<String> alldocuments = new HashSet<String>();

		// index ../datasets/Dataset1/group1
//		System.out.println(command.length());

		String dataset = command.substring(command.length() - 15, command.length() - 7);
		String group = command.substring(command.length() - 6);

		setdatasetvalue = dataset;
		groupValue = group;

		IndexStore storeIndex = new IndexStore();
		// contains documents of all groups inside a dataset
		alldocuments = storeIndex.indexFiles("src//main//resources//", setdatasetvalue, groupValue, 1);

		return alldocuments;
	}

	public Set<String> SearchMethod(String command) {

		String input = command.substring(7);
		ClientSideEngine engine = new ClientSideEngine();
		System.out.println("Inside search");
		Scanner sc = new Scanner(System.in);

		// to be reused -removed for performing multithreading
		Map<String, Set<String>> resultantMap = new HashMap<String, Set<String>>();
		//resultantMap = engine.generateDocWordPair("src//main//resources//", setdatasetvalue);

	//	System.out.print("Enter no. of threads : ");
		int numOfthreads = 2;

		if (input.contains(" OR ")) {
			System.out.println("OR method");
			return engine.MultiThreadingSearchingWithOR(resultantMap, numOfthreads, input);
//			return engine.alphaNumericStringWithOR(input, resultantMap, setdatasetvalue, groupValue);

		} else if (input.contains(" AND ")) {
			return engine.MultiThreadingSearchingWithAND(resultantMap, numOfthreads, input);
//			return engine.alphaNumericStringWithAND(input, resultantMap, setdatasetvalue, groupValue);

		} else {
			return engine.MultiThreadingSearching(resultantMap, numOfthreads, input);
//			return engine.alphaNumericString(input, resultantMap, setdatasetvalue, groupValue);
		}
//		resultantMap = null;

	}

}
