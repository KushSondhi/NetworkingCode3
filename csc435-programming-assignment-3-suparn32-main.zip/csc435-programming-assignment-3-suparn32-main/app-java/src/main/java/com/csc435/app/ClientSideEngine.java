package com.csc435.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClientSideEngine {

	Map<String, Set<String>> documentWordPair = new HashMap<String, Set<String>>();

	// TO-DO keep track of the connection

	public void indexFiles() {
		// TO-DO implement index files method
	}

	public void searchFiles() {
		// returns a list of files that contains the word

	}

	public void openConnection() {
		// TO-DO implement connect to server
	}

	public void closeConnection() {
		// TO-DO implement disconnect from server
	}

	public Set<String> alphaNumericString(String input, Map<String, Set<String>> mapSet, String dataSetName,
			String groupName) {

		long startTime = System.nanoTime();
		Set<String> resultantSet = new HashSet<String>();

		for (Map.Entry<String, Set<String>> mapEntry : mapSet.entrySet()) {
			if (mapEntry.getValue().contains(input)) {
//				resultantArray.add(dataSetName + "/" + groupName + "/" + mapEntry.getKey());
				resultantSet.add(mapEntry.getKey());
			}
		}
		long endTime = System.nanoTime();
		long time = (endTime - startTime);
		System.out.print("Search completed in " + time + " nanoseconds. ");
		System.out.println("Search results: " + resultantSet.size());
		return resultantSet;
//		return "" + time;
	}

	public Set<String> alphaNumericStringWithAND(String input, Map<String, Set<String>> mapSet, String dataSetName,
			String groupName) {

		long startTime = System.nanoTime();
		Set<String> resultantSet = new HashSet<String>();

		ArrayList<String> inputItems = new ArrayList<String>();

		for (String word : input.split(" ")) {
			if (!word.equals("AND")) {
				inputItems.add(word);
//				System.out.println(word);
			}
		}

		for (Map.Entry<String, Set<String>> mapEntry : mapSet.entrySet()) {
			if (mapEntry.getValue().containsAll(inputItems)) {
//				resultantSet.add(dataSetName + "/" + groupName + "/" + mapEntry.getKey());
				resultantSet.add(mapEntry.getKey());
			}
		}

		long endTime = System.nanoTime();
		long time = endTime - startTime;
		System.out.print("Search completed in : " + time + " nanoseconds. ");
		System.out.println("Search results : " + resultantSet.size());
		return resultantSet;
	}

	public Set<String> alphaNumericStringWithOR(String input, Map<String, Set<String>> mapSet, String datasetName,
			String groupName) {

		long startTime = System.nanoTime();
		Set<String> resultantSet = new HashSet<String>();

		ArrayList<String> inputItems = new ArrayList<String>();
		for (String word : input.split(" ")) {
			if (!word.equals("OR")) {
				inputItems.add(word);
				System.out.println(word);
			}
		}

		for (String word : inputItems) {
			for (Map.Entry<String, Set<String>> mapEntry : mapSet.entrySet()) {
				if (mapEntry.getValue().contains(word)) {
//					resultantSet.add(datasetName + "/" + groupName + "/" + mapEntry.getKey());
					resultantSet.add(mapEntry.getKey());
				}
			}
		}

		long endTime = System.nanoTime();
		;
		long time = endTime - startTime;
		System.out.print("Search completed in " + time + " nanoseconds. ");
		System.out.println("Search results : " + resultantSet.size());
		return resultantSet;
	}

	public Set<String> MultiThreadingSearching(Map<String, Set<String>> mapSet, int numOfThreads, String input) {

		Instant startTime = Instant.now();

		System.out.println("MultiThreading Searching...");
		int n = mapSet.size();
		int chunkSize = n / numOfThreads;

		List<Thread> threads = new ArrayList<>();
		Set<String> resultantSet = new HashSet<String>();

		for (int i = 0; i < numOfThreads; i++) {

			int temp = i;
			Thread t = new Thread(() -> {
				int start = temp * chunkSize;
				int end = (temp == numOfThreads - 1) ? n : (temp + 1) * chunkSize;

				for (int j = start; j < end; j++) {
					Object firstKey = mapSet.keySet().toArray()[j];

					if (mapSet.get(firstKey).contains(input)) {
						resultantSet.add(firstKey.toString());
					}
					firstKey = null;
				}

			});
			threads.add(t);
			t.start();
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
//				return (int) Thread.currentThread().getId() * chunkSize;
			}
		}
		Instant endTime = Instant.now();
		long time = Duration.between(startTime, endTime).toMillis();
		System.out.print("Search completed in " + time + " ms. ");
		System.out.println("Total results " + resultantSet.size());
		return resultantSet;
	}

	public Set<String> MultiThreadingSearchingWithAND(Map<String, Set<String>> mapSet, int numOfThreads, String input) {

		Instant startTime = Instant.now();

		int n = mapSet.size();
		int chunkSize = n / numOfThreads;

		List<Thread> threads = new ArrayList<>();
		Set<String> resultantSet = new HashSet<String>();
		ArrayList<String> inputItems = new ArrayList<String>();

		for (String word : input.split(" ")) {
			if (!word.equals("AND")) {
				inputItems.add(word);
//				System.out.println(word);
			}
		}

		for (int i = 0; i < numOfThreads; i++) {

			int temp = i;
			Thread t = new Thread(() -> {
				int start = temp * chunkSize;
				int end = (temp == numOfThreads - 1) ? n : (temp + 1) * chunkSize;

				for (int j = start; j < end; j++) {
					Object firstKey = mapSet.keySet().toArray()[j];

					if (mapSet.get(firstKey).containsAll(inputItems)) {
						resultantSet.add(firstKey.toString());
					}
					firstKey = null;
				}
			});
			threads.add(t);
			t.start();
		}
		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		Instant endTime = Instant.now();
		long time = Duration.between(startTime, endTime).toMillis();
		System.out.print("Search completed in " + time + " ms. ");
		System.out.println("Total results " + resultantSet.size());
		return resultantSet;
	}

	public Set<String> MultiThreadingSearchingWithOR(Map<String, Set<String>> mapSet, int numOfThreads, String input) {

		Instant startTime = Instant.now();

		Set<String> resultantSet = new HashSet<String>();
		ArrayList<String> inputItems = new ArrayList<String>();
		for (String word : input.split(" ")) {
			if (!word.equals("OR")) {
				inputItems.add(word);
//				System.out.println(word);
			}
		}

		int n = mapSet.size();
		int chunkSize = n / numOfThreads;

		List<Thread> threads = new ArrayList<>();

		for (int i = 0; i < numOfThreads; i++) {

			int temp = i;
			Thread t = new Thread(() -> {
				int start = temp * chunkSize;
				int end = (temp == numOfThreads - 1) ? n : (temp + 1) * chunkSize;

				for (int j = start; j < end; j++) {
					Object firstKey = mapSet.keySet().toArray()[j];

					for (String word : inputItems) {
						if (mapSet.get(firstKey).contains(word)) {
							resultantSet.add(firstKey.toString());
							break;
						}
					}
					firstKey = null;
				}

			});
			threads.add(t);
			t.start();
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
//				return (int) Thread.currentThread().getId() * chunkSize;
			}
		}
		Instant endTime = Instant.now();
		long time = Duration.between(startTime, endTime).toMillis();
		System.out.print("Search completed in " + time + " ms. ");
		System.out.println("Total results " + resultantSet.size());
		return resultantSet;
	}

	public Map<String, Set<String>> generateDocWordPair(String pathofResources, String dataSet) {

		File folder = new File(pathofResources + dataSet);
		File[] allgroups = folder.listFiles();

		for (File f : allgroups) {
			IterateOverdataSetdocuments(f.getAbsolutePath());
		}

		return documentWordPair;
	}

	public Map<String, Set<String>> IterateOverdataSetdocuments(String pathOfDataSetgroup) {

		File dataSetgroupfolder = new File(pathOfDataSetgroup);
		File[] documentsindataSetgroup = dataSetgroupfolder.listFiles();

		for (int j = 0; j < documentsindataSetgroup.length; j++) {
			if (documentsindataSetgroup[j].isFile()) {
				documentWordPair.put(documentsindataSetgroup[j].getAbsolutePath().substring(105),
						generateSetOfUniqueWords(documentsindataSetgroup[j].getPath().toString()));
			}
		}
		return documentWordPair;
	}

	public Set<String> generateSetOfUniqueWords(String pathofdoc) {

		Set<String> setKeyWords = new HashSet<String>();
		try (BufferedReader buffer = new BufferedReader(new FileReader(pathofdoc))) {

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str.toString().replaceAll("[^A-Za-z0-9@:.]", " ").replaceAll("\\*", "").replace("\n", "");
				for (String s : str.split(" ")) {
					setKeyWords.add(s.replaceAll("[^A-Za-z0-9@]", ""));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return setKeyWords;
	}
}
