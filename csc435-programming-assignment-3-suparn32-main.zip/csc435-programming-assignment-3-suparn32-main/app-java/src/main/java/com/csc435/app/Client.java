package com.csc435.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Client {

	static List<String> alldocuments = new ArrayList<String>();
	static Map<String, Set<String>> documentWordPair = new HashMap<String, Set<String>>();
	static ClientSideEngine engine = new ClientSideEngine();
	static String serverAddress = "localhost";
	static int port = 1111;
	static List<Socket> allSockets = new ArrayList<>();

	static List<String> tempAlldocuments = new ArrayList<String>();
	static Map<String, Set<String>> tempdocWordPairs = new HashMap<String, Set<String>>();

	public static void main(String[] args) throws Exception {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter no. of Clients : ");
		int numOfClients = sc.nextInt();

		System.out.println("Welcome !!!");
		System.out.println("Choose from below commands :");
//		System.out.println("Index Datasets/group (eg. index ../Dataset1/group1)");
//		System.out.println("Searching (search programming)");
		System.out.println("<connect | list | index (index ../Dataset1/group1) | search (search (keyword) ) | quit>");

		while (true) {

			String input = sc.nextLine();

			if (input.equalsIgnoreCase("list")) {

				System.out.println("Showing All the connections...");
				for (Socket socket : allSockets) {
					System.out.println(socket);
				}
			}

			else if (input.contains("connect")) {

				String host = "localhost";
				int port = 1111;

				CreateSockets();
			}

			else if ((input.length() >= 5 && input.substring(0, 5).compareTo("index") == 0)) {

//				Instant startTime = Instant.now();
//				long startTime = System.currentTimeMillis();

				System.out.println("Performing indexing using " + numOfClients + " clients");
				String dataset = "";
				String group = "";
				String pathOfDataset = "";

				String[] vals = input.split("/");
				dataset = vals[1];
				if (vals.length > 2) {
					group = vals[2];
					pathOfDataset = "src//main//resources//" + dataset + "//" + group;
				}
				else {
					pathOfDataset = "src//main//resources//" + dataset;
				}
//				pathOfDataset = "src//main//resources//" + dataset;
				File folder = new File(pathOfDataset);

				if (folder.exists() && folder.isDirectory()) {
					listTxtfiles(folder);
				} else {
					System.out.println("Invalid folder path");
				}
				System.out.println("Total documents found: " + alldocuments.size());
				for (String docs : alldocuments) {
					tempAlldocuments.add(docs);
				}
				SocketIndexing(numOfClients);

//				Instant endTime = Instant.now();
//				long temp = tempAlldocuments.size();
//				long time = Duration.between(startTime, endTime).toMillis();
//				System.out.println("Completed Indexing in " + time + temp + " ms. ");

			}

			else if (input.length() >= 6 && input.substring(0, 6).compareTo("search") == 0) {

				String word = input.substring(7);
				ClientSideEngine engine = new ClientSideEngine();
				while (!tempAlldocuments.isEmpty()) {
					String document = tempAlldocuments.remove(0);
					MapdocumentsWords(document);
				}
				if (!documentWordPair.isEmpty()) {
					tempdocWordPairs.putAll(documentWordPair);
				}

				// System.out.println("Total documentWordPairs : " + tempdocWordPairs.size());
				SocketSearching(numOfClients);
				System.out.println("Socket searching completed...");
				System.out.print("Enter no. of threads : ");
				int numOfthreads = sc.nextInt();
				if (word.contains("OR")) {
					// System.out.println("Searching in OR");
					System.out.println(engine.MultiThreadingSearchingWithOR(tempdocWordPairs, numOfthreads, word));
//					System.out.println(engine.alphaNumericStringWithOR(word, tempdocWordPairs, "input", "output"));
				} else if (word.contains(" AND ")) {
					// System.out.println("Searching in AND");
					System.out.println(engine.MultiThreadingSearchingWithAND(tempdocWordPairs, numOfthreads, word));
//					System.out.println(engine.alphaNumericStringWithAND(input, tempdocWordPairs, "maximum", "gen"));
				} else {
					System.out.println(engine.MultiThreadingSearching(tempdocWordPairs, numOfthreads, word));
					// System.out.println("Size of tempdocWordPairs" + tempdocWordPairs.size());
//					System.out.println(engine.alphaNumericString(word, tempdocWordPairs, "abc", "ghi"));
				}
			}

			else if (input.contains("quit")) {

				ServerSideEngine sEngine = new ServerSideEngine();

				for (Socket socket : allSockets) {
					System.out.println("Closing connection : " + socket);
//					socket.close();
					sEngine.shutdown(socket);
					System.out.println("Connection closed");
				}
				allSockets = null;
				break;
			}
			continue;
		}
		System.out.println("******Program Completed Successfully******");
	}

	public static void listTxtfiles(File folder) {
		File[] allFiles = folder.listFiles();
		if (allFiles != null) {
			for (File file : allFiles) {
				if (file.isDirectory()) {
					listTxtfiles(file);
				} else if (file.isFile()) {
					alldocuments.add(file.getPath());
				}
			}
		}
	}

	public static void MapdocumentsWords(String pathOfdocument) {

		// System.out.println(pathOfdocument);
		Set<String> keyWords = engine.generateSetOfUniqueWords(pathOfdocument);
		documentWordPair.put(pathOfdocument.substring(28), keyWords);
		keyWords = null;
	}

	// 1.Extract all documents from a Dataset
	// 2. Map<String,Set<String>> - String: documentName, Set<String> : All unique
	// Set of Keywords in all documents.
	// 3. Multi threading on this Map.

	public static void CreateSockets() {

		try (Socket s = new Socket(serverAddress, port);
				PrintWriter out = new PrintWriter(s.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()))) {
			System.out.println("Socket Connection Successful");
			allSockets.add(s);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void SocketIndexing(int numOfClients) throws InterruptedException {


		long startTime = System.currentTimeMillis();
		for (int i = 0; i < numOfClients; i++) {
			final int clientId = i;
//			int docsProcessed = 0;
			 new Thread(() -> {
				try (Socket s = new Socket(serverAddress, port);
						PrintWriter out = new PrintWriter(s.getOutputStream(), true);
						BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()))) {

					int docsProcessed = 0;

					if (!alldocuments.isEmpty()) {
						while (!alldocuments.isEmpty()) {

							synchronized (alldocuments) {
								if (!(alldocuments.isEmpty())) {
									String document = alldocuments.remove(0);
									out.println("Client " + clientId + " is processing : " + document);
									Thread.sleep(1000);
//									String response = in.readLine();
//									System.out.println(response);
									docsProcessed++;
								}
							}
						}
					}
					System.out.println("Client : " + clientId + " processed " + docsProcessed + " documents.");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}).start();
		}
		Thread.currentThread();
		Thread.sleep(1000);
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime - alldocuments.size();
		
		System.out.println("Total time : "+ totalTime);
	}

	public static void SocketSearching(int numOfClients) throws InterruptedException {

		int documentsPerClient = documentWordPair.size() / numOfClients;
		for (int i = 0; i < numOfClients; i++) {

			final int clientId = i;
//			int docsProcessed = 0;
			List<Set<String>> setOfWords = new ArrayList<>();
			List<String> documentNames = new ArrayList<>();

			// distributing documents dynamically to each thread
			for (int j = 0; j < documentsPerClient; j++) {
				if (!documentWordPair.isEmpty()) {
					Map.Entry<String, Set<String>> entry = documentWordPair.entrySet().iterator().next();
					String documentName = entry.getKey();
					Set<String> wordSet = entry.getValue();

					setOfWords.add(wordSet);
					documentNames.add(documentName);
					documentWordPair.remove(documentName);
				}
			}
			// System.out.println("Set of Words :" + setOfWords.size());
			// System.out.println("document Names" + documentNames.size());

			new Thread(() -> {
				try (Socket s = new Socket(serverAddress, port);
						PrintWriter out = new PrintWriter(s.getOutputStream(), true);
						BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()))) {

					int docsProcessed = 0;

					if (!documentNames.isEmpty()) {
						while (!setOfWords.isEmpty() && !documentNames.isEmpty()) {
							synchronized (documentNames) {
								if (!documentNames.isEmpty()) {
									String doc = documentNames.remove(0);
									Set<String> wordSet = setOfWords.remove(0);
//									Set<String> wordSet = (Set<String>) setOfWords.iterator().next();
									out.println(
											"Client " + clientId + " is processing : " + doc + "-- " + wordSet.size());
									// System.out.println(
									// "Client " + clientId + " is processing : " + doc + "-- " + wordSet.size());
									Thread.sleep(1000);
									docsProcessed++;
								}
							}
						}
						System.out.println("Client : " + clientId + " processed" + docsProcessed + " documents.");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}).start();
		}
		Thread.currentThread();
		Thread.sleep(10000);
//		tempdocWordPairs = null;
	}

	// This function will return 128 randomly selected queries
	// You need to place tests-Dataset folder inside src/main/resources directory.
	public static void searchLatency() throws IOException {

		List<String> queries = new ArrayList<String>();
		System.out.println("reading test file...");
		IndexStore storeIndex = new IndexStore();
		queries = storeIndex.lookupIndex();

		for (String q : queries) {
			System.out.println(q);
		}
		System.out.println(queries.size());
	}
}
