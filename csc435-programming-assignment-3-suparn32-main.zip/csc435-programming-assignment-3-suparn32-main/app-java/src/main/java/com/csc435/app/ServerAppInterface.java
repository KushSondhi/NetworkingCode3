package com.csc435.app;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ServerAppInterface extends Thread {

	private ServerSideEngine engine;
	private ArrayList<ServerAppInterface> threadList;

	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;

	public ServerAppInterface(Socket s, DataInputStream dis, DataOutputStream dos,
			ArrayList<ServerAppInterface> threads) {

		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.threadList = threads;
	}

	@Override
	public void run() {

		String msgReceived;
		String msgToReturn;

		System.out.println("[SERVER] : What do you want \n<list | quit>]");

		while (true) {

			try {
				msgReceived = dis.readUTF();
				System.out.println("[CLIENT] : " + msgReceived);

				switch (msgReceived) {

				case "list":
					msgToReturn = s.getLocalAddress().toString() + ":" + s.getPort();
					dos.writeUTF(msgToReturn);
					// System.out.println("[SERVER]:" + dos.toString());
					continue;

				case "quit":
					dos.writeUTF("Client " + this.s + " sends quit...Closing connection.\n");
					this.s.close();
					dos.writeUTF("Connection closed");
					break;

				default:
					dos.writeUTF("Invalid Input...");
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				break;
			}
		}
	}

//	public void printToAllClients(String outputString) {
//		for (ServerThread st : threadList) {
//			st.msgReceived.println(outputString);
//		}
//	}
}
