package com.csc435.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class IndexStore {

	Set<String> documents = new HashSet<String>();
	List<String> docsPath = new ArrayList<String>();

	public IndexStore() {

	}

	public void insertIndex() {
		// TO-DO implement index insert method
	}

	public List<String> lookupIndex() throws IOException {
		// TO-DO implement index lookup method
		// to implement reading of test datasets file

		Set<String> queries = new HashSet<String>();

		String path = "src//main/resources//Dataset-tests-groups";
		File folder = new File(path);
		
		if (folder.exists() && folder.isDirectory()) {
			listFiles(folder);
		} else {
			System.out.println("Invalid folder path");
		}

		BufferedReader reader;
		for (String docName : docsPath) {
			reader = new BufferedReader(new FileReader(path + "//" + docName));

			String line = reader.readLine();

			while (line != null) {
				if (!(line.contains("Dataset"))) {
					queries.add(line);
//					System.out.println(line);
				}
				line = reader.readLine();
			}
		}
		List<String> allqueries = new ArrayList<String>();
		allqueries.addAll(queries);
		Collections.shuffle(allqueries);
//		reader.close();
		if (allqueries.size()>128) {
			return allqueries.subList(0, 128);
		}
		return allqueries;

	}

	public void listFiles(File folder) {
		File[] allFiles = folder.listFiles();
		if (allFiles != null) {
			for (File file : allFiles) {
				if (file.isDirectory()) {
					listFiles(file);
				} else if (file.isFile()) {
					docsPath.add(file.getName());
				}
			}
		}
	}

	public Set<String> indexFiles(String pathOfResources, String nameOfdataset, String nameOfgroup, int noOfThreads) {

//		File folder = new File(pathOfResources + nameOfdataset);
//		File[] allgroups = folder.listFiles();
//
//		for (File f : allgroups) {
//			listAlldocumentsAnddataSets(pathOfResources, nameOfdataset, nameOfgroup, noOfThreads);
//		}

		listAlldocumentsAnddataSets(pathOfResources, nameOfdataset, nameOfgroup, noOfThreads);
		return documents;

	}

	public Set<String> listAlldocumentsAnddataSets(String pathOfResources, String nameOfdataset, String nameOfgroup,
			int noOfThreads) {

		Instant startTime = Instant.now();
		File dataSetgroup = new File(pathOfResources + "//" + nameOfdataset + "//" + nameOfgroup);
		File[] alldocuments = dataSetgroup.listFiles();

		int n = alldocuments.length;
//		System.out.println("Total no. of documents : " + n);
		int chunkSize = n / noOfThreads;

		List<Thread> threads = new ArrayList<>();

		for (int i = 0; i < noOfThreads; i++) {
			int temp = i;
			Thread t = new Thread(() -> {
				int start = temp * chunkSize;
				int end = (temp == noOfThreads - 1) ? n : (temp + 1) * chunkSize;

				for (int j = start; j < end; j++) {
					documents.add(nameOfdataset + "/" + nameOfgroup + "/" + alldocuments[j].getName().toString());
					// System.out.println(alldocuments[j]);
				}
			});
			threads.add(t);
			t.start();
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

//		System.out.println(documents);

		Instant end = Instant.now();
		long time = Duration.between(startTime, end).toMillis();
		System.out.println("Completed Indexing " + nameOfdataset + "/" + nameOfgroup + " in " + time + " ms");
		startTime = end = null;
		return (documents);

	}
}
