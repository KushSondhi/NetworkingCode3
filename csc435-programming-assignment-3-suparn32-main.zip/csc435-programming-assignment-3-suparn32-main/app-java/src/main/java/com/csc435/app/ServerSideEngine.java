package com.csc435.app;

import java.io.IOException;
import java.net.Socket;

public class ServerSideEngine {
    private IndexStore store;

    public ServerSideEngine(IndexStore store) {
        this.store = store;
        // TO-DO implement constructor
    }
    public ServerSideEngine() {
    	
    }

    public void initialize() {
        // TO-DO create one dispatcher threads
    }
    
    public void runDispatcher() {
        // TO-DO create the server socket and listen for and accept new connections
        // HINT each new connection gets managed by a different worker thread -> create new worker thread
    	// creating socket, listening connection, accept the connections from clients
    	//accept -> a new client socket 
    }

    public void runWorker() {
        // TO-DO receive and index data from the client until the client disconnects
    	// index, search
    	//index - receive a line and file - tokenize the data in the line , extracts all words
    	// update Indexstore with latest index file, & again listen for new queries.
    }

    public void shutdown(Socket s) throws IOException {
        s.close();
    }
}
