#include "ServerSideEngine.hpp"

ServerSideEngine::ServerSideEngine(std::shared_ptr<IndexStore> store) : store(store) {
    // TO-DO implement constructor
}

void ServerSideEngine::initialize() {
    // TO-DO create one dispatcher threads
}

void ServerSideEngine::runDispatcher() {
    // TO-DO create the server socket and listen for and accept new connections
    // HINT each new connection gets managed by a different worker thread -> create new worker thread
}

void ServerSideEngine::runWorker() {
    // TO-DO receive and index data from the client until the client disconnects
}

void ServerSideEngine::shutdown() {
    // TO-DO join the dispatcher and worker threads
}