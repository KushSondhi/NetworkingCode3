#include "ClientSideEngine.hpp"

ClientSideEngine::ClientSideEngine() {
    // TO-DO implement constructor
}

void ClientSideEngine::indexFiles() {
    // TO-DO implement index files method
}

void ClientSideEngine::searchFiles() {
    // TO-DO implement search files method
}

void ClientSideEngine::openConnection() {
    // TO-DO implement connect to server
}

void ClientSideEngine::closeConnection() {
    // TO-DO implement disconnect from server
}