#include "IndexStore.hpp"

IndexStore::IndexStore() {
    // TO-DO implement constructor
}

void IndexStore::insertIndex() {
    // TO-DO implement index insert method
}

void IndexStore::lookupIndex() {
    // TO-DO implement index lookup method
}
